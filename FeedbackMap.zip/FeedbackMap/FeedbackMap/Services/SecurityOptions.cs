namespace FeedbackMap.Services;

/// <summary>Sikkerhetsinnstillinger. RequireTwoFactor=false slår av to-faktor (kun for lokal utvikling).</summary>
public class SecurityOptions
{
    public const string SectionName = "Security";

    public bool RequireTwoFactor { get; set; } = true;
}
