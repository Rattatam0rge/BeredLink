namespace FeedbackMap.Models;

/// <summary>Navn på autorisasjonspolicyer.</summary>
public static class Policies
{
    /// <summary>Innlogget OG fullført 2FA (amr-claim "mfa").</summary>
    public const string RequireMfa = "RequireMfa";
}
