# BeredLink – ressurs- og behovsportal for Totalforsvaret

*Ressurser · Samarbeid · Beredskap*

Webapplikasjon for krisehåndtering: offentlige aktører (kommune, politi, brann, helse, Sivilforsvaret,
Heimevernet) registrerer **behov**, og innbyggere, bedrifter og frivillige registrerer **ressurser**
(med bilde). Alt vises på ett kart (Leaflet + Kartverket), og kriseledelsen kan tildele ressurser til behov.

Bygget i emnene IS-200 og IS-201 (Universitetet i Agder) i samarbeid med Kartverket og Heimevernet.

## Krav

Du trenger bare **Docker Desktop** (og Git for å hente koden). .NET SDK og MariaDB trenger du **ikke**
installere. Alt bygges og kjøres i containere.

- Docker Desktop: https://www.docker.com/products/docker-desktop/
- Git: https://git-scm.com/downloads

## Kom i gang

```bash
git clone <URL-til-repoet>
cd <mappenavn>
docker compose up --build
```

Åpne deretter **http://localhost:8080**.

Første oppstart tar noen minutter. Databasen og alle tabeller opprettes automatisk.
Du trenger ingen `.env`-fil (se *Konfigurasjon*).

## Første gangs bruk

1. Klikk **Registrer deg** og velg rolle: *Offentlig aktør* eller *Ressursleverandør*.
2. Du kommer rett til kartet og er innlogget.

Tips for å teste begge roller samtidig: bruk to nettlesere, eller ett vanlig og ett privat vindu.

## Funksjoner

**Kart**
- Kartbakgrunn fra Kartverket, filter (type, akutt/planlagt, ressurser, offentlige aktører), tegnforklaring som kan minimeres
- Søkefelt for adresse, sted og postnummer (Kartverkets åpne API-er)
- Symbol per type (traktor, lastebil, aggregat, båt, mannskap osv.) med hvit og svart kant for kontrast
- Ressurser som ligger tett samles i klynger, slik at kartet er lesbart også med hundrevis av ressurser
- **Radiusfilter rundt et behov:** velg et behov, og se bare ressurser innen 500 m, 1, 2, 5 eller 10 km (valgfritt bare passende typer)
- **Skriv ut ressursliste** for dagens kartutsnitt (region)
- Oppdateres automatisk hvert 30. sekund

**Offentlig aktør**
- Registrere behov i et panel over kartet (sted velges i kartet)
- Se ressurser i nærheten av et behov, sortert på avstand, og **tildele** dem. Ressurser kan ikke dobbelttildeles
- Statusflyt: ny → vurderes → tildelt → løst, med historikk og tidsstempel
- Avbryte tildeling, sette organisasjonens posisjon (blå markør), aktivitetslogg

**Ressursleverandør**
- Registrere ressurs med **bilde**, sted og tilgjengelighet. Bildet vises i kartpopup og lister
- **Endre** egne ressurser (type, sted, tidspunkter, bilde) og fjerne dem
- **Varsler** (med teller i menyen) når en ressurs tildeles eller tildelingen avbrytes

## Kravsporing mot oppgaven

| # | Krav | Slik er det løst |
|---|---|---|
| 1 | Kobling mot MariaDB, begge kjøres i Docker | `docker-compose.yml` starter `web` og `db`. EF Core mot MariaDB 11.4, migrasjoner kjøres automatisk |
| 2 | Registrering av ny bruker, lagret i databasen | `AccountController.Register` (ASP.NET Core Identity). Bruker, rolle og profil lagres i `AspNetUsers`, `PublicActor` og `ResourceProvider` |
| 3 | Innlogging og autorisering, legge til, **endre** og slette ressurs | Innlogging med e-post og passord, rollebasert tilgang. Ressurs: registrere (`Resource/Create`), endre (`Resource/Update`, fra kartpopup eller listen) og slette (`Resource/Delete`). Kun eier får endre og slette |
| 4 | Funksjonalitet som oppdragsgiver beskriver | Roller, behov, ressurser, kart med fargekoder, matching, statusflyt ny → vurderes → tildelt → løst, utskrift av regionliste |
| 5 | Kartskjema der man legger punkt på kartet | Registreringspanelet: trykk i kartet, dra pinnen eller bruk egen posisjon. Samme kart som hovedvisningen |
| 6 | Mobiltilpasset frontend | Se *Mobiltilpasning* under |
| 7 | Enkel oversikt over ressurser | Kartet (filter, klynger, radius) og ressurslisten `/Resource`. Leverandører ser egne ressurser |
| 8 | Sikkerhetstiltak | Se *Sikkerhetstiltak* |
| 9 | Testing | Se *Testing*: enhetstester, manuelle scenarier for system, sikkerhet og brukervennlighet |
| 10 | Dokumentasjon i GitHub | Denne README: drift, arkitektur, testscenarier. Resultatkolonnen fylles ut etter testing |
| 11 | Dokumentasjon i koden | XML-kommentarer på alle offentlige klasser, interfaces og controller-handlinger, og forklarende kommentarer i JavaScript og CSS |

## Mobiltilpasning

- Responsivt oppsett (Bootstrap) med `viewport`-tag. Menyen blir en hamburgermeny under 992 px
- Toppbaren har tre kolonner (logo, søk, meny) på laptop, så søkefeltet tar plassen som blir igjen og aldri dekker menyvalg. På mobil ligger søket mellom logo og menyknapp
- **Registrering på mobil:** panelet er et bunnark. «Vis kart» minimerer det slik at hele kartet er synlig mens man velger sted. Trykk i kartet, så vises skjemaet igjen med punktet i øvre del av skjermen
- Tabeller (behov, ressurser, tildelinger) vises som kort uten sideveis scrolling
- Tegnforklaringen er minimert som standard på små skjermer, og valget huskes
- Alle knapper er minst 44 px høye, og tekstfelt bruker 16 px skrift (hindrer at iPhone zoomer inn)
- Bilde kan tas direkte med kameraet i opplastingsfeltet
- Startsiden har fullbreddeknapper og redusert animasjon på små skjermer

**Slik tester du mobil**

1. Nettleserens utviklerverktøy: F12, deretter «Toggle device toolbar» (Ctrl+Shift+M). Test 360×640, 390×844, 768×1024 og 1366×768
2. Ekte telefon på samme Wi-Fi: åpne `http://<PC-ens IP>:8080` (Windows-brannmuren må tillate port 8080). «Bruk min posisjon» virker da ikke, siden nettlesere krever HTTPS for posisjon. Bruk en HTTPS-tunnel (f.eks. Cloudflare Tunnel eller ngrok) hvis du vil teste den

## Roller og tilgang

| | Offentlig aktør | Ressursleverandør |
|---|---|---|
| Registrere behov | ✔ | |
| Se alle behov og tilgjengelige ressurser | ✔ | |
| Tildele ressurser, endre status | ✔ | |
| Sette organisasjonens posisjon, se aktivitetslogg | ✔ | |
| Skrive ut ressursliste for en region | ✔ | |
| Registrere, endre og fjerne egne ressurser (med bilde) | | ✔ |
| Se egne ressurser og varsler | | ✔ |

Alle funksjoner krever innlogging.

## Kartsymboler

| Form og farge | Betydning |
|---|---|
| Rød trekant | Akutt behov |
| Gul rombe | Planlagt behov |
| Grønn sirkel | Tilgjengelig ressurs |
| Blå firkant | Offentlig aktør |

Ikonet inni viser typen. Samlemarkør (grønn sirkel med tall) viser flere ressurser som ligger tett.

## Sikkerhetstiltak

| Tiltak | Beskrivelse |
|---|---|
| Autentisering | ASP.NET Core Identity, passord hashes, minst 10 tegn med store/små bokstaver og tall |
| Utestenging | Konto låses 5 minutter etter 3 feil passord |
| Rate limiting | Maks 15 forsøk i minuttet per IP mot innlogging og registrering |
| Autorisasjon | Rollebasert (`PublicActor`, `ResourceProvider`) og krav om innlogging på alle sider unntatt startside, innlogging og registrering. Eierskapssjekk ved sletting og bildevisning |
| CSRF | Antiforgery-token kreves på alle POST-forespørsler |
| XSS | Brukerdata bygges inn med `textContent`/Razor-koding. Streng Content-Security-Policy (kun egne skript) |
| Sikkerhetshoder | CSP, `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy` |
| Filopplasting | Filtype avgjøres av innholdet (JPEG/PNG/WebP), maks 5 MB, tilfeldig filnavn, lagres utenfor `wwwroot`, vises kun til innloggede |
| Personvern | Bilder skaleres i nettleseren, og EXIF (f.eks. GPS-posisjon) fjernes før opplasting |
| Dataintegritet | Unik indeks hindrer to aktive tildelinger av samme ressurs, også ved samtidige forespørsler |
| Sporbarhet | Aktivitetslogg for innlogging, registrering, tildeling, statusendringer og sletting |
| Hemmeligheter | Passord og tilkobling ligger i miljøvariabler/`.env`, ikke i koden |
| Lokale biblioteker | Leaflet og klyngebibliotek hostes lokalt (ingen eksterne skript) |

> Passordene i `docker-compose.yml` er kun utviklingsverdier. Ved ekte drift må de byttes, og
> HTTPS må settes opp foran applikasjonen (reverse proxy).

## Testing

### Automatiske tester (enhetstester)

```bash
dotnet test FeedbackMap.Tests/FeedbackMap.Tests.csproj
```

Krever .NET SDK 10. Testene kjører mot en in-memory database og dekker blant annet:

| Område | Eksempler |
|---|---|
| Statusflyt | ny → vurderes → tildelt → løst, ugyldige overganger avvises, historikk loggføres |
| Tildeling | Tildeling setter status og oppretter varsel, ingen dobbelttildeling, avbrutt tildeling frigjør ressurs |
| Matching | Radius, sortering på avstand, passende typer, ressurser som allerede er tildelt vises ikke |
| Ressurser | Endring (kun eier, ikke mens tildelt, bytte/fjerning av bilde), sletting uten historikk/med historikk/mens tildelt, kun egne ressurser, region-filter |
| Bilder | Kun JPEG/PNG/WebP etter innhold (ikke filnavn), størrelsesgrense, stiangrep (path traversal) |
| Varsler og logg | Kun eier kan lese og markere varsler, viktige handlinger skrives til loggen |
| Geografi | Avstandsberegning (haversine) |

Testene kjøres også automatisk på GitHub (`.github/workflows/ci.yml`).

### Manuelle testscenarier

Fyll ut kolonnen *Resultat* (OK / feil + kommentar) når scenariene er utført.

| # | Type | Scenario | Forventet | Resultat |
|---|---|---|---|---|
| 1 | System | Registrer offentlig aktør | Brukeren lagres, innlogget, kartet åpnes | |
| 2 | System | Registrer ressursleverandør | Brukeren lagres, innlogget, kartet åpnes | |
| 3 | System | Offentlig aktør registrerer behov via panel på kartet | Behovet vises som rød trekant og i listen | |
| 4 | System | Leverandør registrerer ressurs med bilde | Grønn markør med ikon, bildet vises i popup og liste | |
| 5 | System | Velg et behov og bruk radiusfilter (500 m, 1 km …) | Kun ressurser innen radius vises, antall oppgis | |
| 6 | System | Tildel ressurs fra behovssiden | Status blir «Tildelt», leverandør får varsel | |
| 7 | System | Forsøk å tildele samme ressurs til et annet behov | Avvises med melding | |
| 8 | System | Avbryt tildeling | Status tilbake til «Vurderes», leverandør varsles, ressursen er ledig | |
| 9 | System | Sett behov til «Løst» | Tildelinger fullføres, ressurser frigjøres | |
| 10 | System | Skriv ut ressursliste for kartutsnitt | Utskriftsvennlig liste med riktige ressurser | |
| 11 | Sikkerhet | 3 feil passord på rad | Konto låses i 5 minutter | |
| 12 | Sikkerhet | Åpne `/Need`, `/Audit` og `/api/map/markers` uten innlogging | Sendes til innlogging | |
| 13 | Sikkerhet | Leverandør åpner `/Need` eller `/Audit` | Ingen tilgang | |
| 14 | Sikkerhet | Leverandør prøver å slette andres ressurs (endre id) | Avvises | |
| 15 | Sikkerhet | Last opp en `.txt`-fil omdøpt til `.jpg` | Avvises, ingen fil lagres | |
| 16 | Sikkerhet | Send skjema uten antiforgery-token | 400-feil | |
| 17 | Sikkerhet | Skriv `<script>alert(1)</script>` i beskrivelse/kontaktpunkt | Vises som tekst, ingenting kjøres | |
| 18 | Sikkerhet | Mange innloggingsforsøk raskt etter hverandre | Blir stoppet (429) | |
| 19 | Brukervennlighet | Registrer behov på mobil | Panel nederst, store knapper, sted kan velges | |
| 20 | Brukervennlighet | Søk på adresse, sted og postnummer | Kartet flytter seg til treffet | |
| 21 | Brukervennlighet | Kontrast: markører på kart med mange symboler | Forskjell på type og kategori er tydelig | |
| 22 | Brukervennlighet | Åpne kartet på 360 px bredde | Toppbar med logo, søk og menyknapp uten overlapp. Tegnforklaring er minimert | |
| 23 | Brukervennlighet | Åpne kartet på laptop (1366×768) | Alle menyvalg og søkefeltet er synlige uten at noe dekkes | |
| 24 | Brukervennlighet | Registrer ressurs på mobil: bruk «Vis kart», trykk i kartet | Skjemaet kommer tilbake, valgt sted vises, punktet er synlig over panelet | |
| 25 | Brukervennlighet | Se behovs- og ressurslister på mobil | Vises som kort, ingen sideveis scrolling | |
| 26 | System | Leverandør endrer en ressurs (type, sted, bilde) | Endringene vises på kart og i liste, gammelt bilde er borte | |
| 27 | System | Forsøk å endre en ressurs som er tildelt | Avvises med melding | |
| 28 | Sikkerhet | Leverandør kaller `/Resource/Update/{id}` for en annen leverandørs ressurs | Avvises (ingen endring) | |

## Daglig bruk

| Handling | Kommando |
|---|---|
| Starte (første gang og etter kodeendring) | `docker compose up --build` |
| Starte i bakgrunnen | `docker compose up -d` |
| Stoppe (data beholdes) | `docker compose down` |
| Se logg | `docker compose logs -f web` |
| Nullstille alt (sletter database og bilder) | `docker compose down -v` |

## Feilsøking

| Problem | Løsning |
|---|---|
| «Docker Desktop kjører ikke» / `error during connect` | Start Docker Desktop og vent til den er klar. |
| `port is already allocated` (8080 eller 3307) | Kopier `.env.example` til `.env` og endre `WEB_PORT` / `DB_PORT`. |
| Siden laster ikke rett etter oppstart | Vent 20–30 sekunder (databasen starter først) og last siden på nytt. |
| Kontoen er låst | Låses 5 minutter etter 3 feil forsøk. Vent, eller nullstill med `docker compose down -v`. |
| Bildet blir ikke lastet opp | Bruk JPEG, PNG eller WebP under 5 MB. |
| «Bruk min posisjon» virker ikke | Nettleseren tillater posisjon bare på `localhost` eller HTTPS. Trykk i kartet i stedet. |
| Kartet er grått | Maskinen trenger internett (kartfliser fra Kartverket). |
| 429 «Too Many Requests» | For mange innloggingsforsøk. Vent ett minutt. |
| Alt er rart etter oppdatering | `docker compose down -v`, deretter `docker compose up --build`. |

## Konfigurasjon

Alt har standardverdier. Vil du endre noe: `cp .env.example .env` (Windows: `copy .env.example .env`).

| Variabel | Standard | Beskrivelse |
|---|---|---|
| `WEB_PORT` | 8080 | Porten appen åpnes på |
| `DB_PORT` | 3307 | Porten databasen åpnes på lokalt (for databaseverktøy) |
| `DB_NAME`, `DB_USER` | feedbackmap | Database og bruker |
| `DB_PASSWORD`, `DB_ROOT_PASSWORD` | *(utviklingspassord)* | Bytt ved annen bruk enn lokal utvikling |

Endrer du passord etter at databasen er opprettet, må du kjøre `docker compose down -v` først.

## Arkitektur

ASP.NET Core MVC (.NET 10) · Entity Framework Core · MariaDB 11.4 · Docker Compose · Leaflet.

```
docker-compose.yml          web + db (+ volum for databasen og bilder)
Dockerfile                  bygger web-applikasjonen
FeedbackMap/                web-prosjektet
  Controllers/              Account, Home, Need, Resource, Actor, Media, Notification, Audit, MapApi (JSON)
  Services/                 forretningslogikk bak interfaces (Need, Resource, Assignment, Notification, Audit, ImageStorage ...)
  Data/                     ApplicationDbContext (EF Core) og Migrations/
  Models/                   entiteter (Need, Resource, Assignment, NeedStatusLog, Notification, AuditLog ...)
  ViewModels/  Views/       data til og visning i Razor
  wwwroot/js/               kart, søk, registreringspanel, startside
  wwwroot/lib/leaflet/      Leaflet og klyngebibliotek (lokalt)
FeedbackMap.Tests/          enhetstester (xUnit)
.github/workflows/ci.yml    bygg og test på GitHub
```

Prinsipper (fra IS-200 designrapport): separation of concerns (controller → service → data),
sikkerhet (Identity, rollebasert tilgang, CSRF, lockout), testbarhet og portabilitet (Docker).

Datamodellen følger IS-201-rapporten: `ACTOR` = ASP.NET Core Identity-bruker, med profiltabellene
`PublicActor` og `ResourceProvider` (class table inheritance), og `Assignment` som koblingstabell mellom
`Need` og `Resource`. Statusen på et behov utledes fra `NeedStatusLog`.

## Eksterne tjenester og lisenser

- Kartbakgrunn: Kartverket (topografisk WMTS), åpne data
- Søk etter adresse, sted og postnummer: Kartverkets/Geonorges åpne API-er
- Ikoner: Material Design Icons (Pictogrammers), Apache License 2.0
- Leaflet 1.9.4 (BSD-2) og Leaflet.markercluster 1.5.3 (MIT), hostet lokalt

## Utvikling uten Docker (valgfritt)

Krever .NET SDK 10 og en kjørende MariaDB (kan startes med `docker compose up db`).

```bash
cd FeedbackMap
dotnet ef migrations add <Navn>      # ny migrasjon (krever: dotnet tool install --global dotnet-ef)
dotnet run                           # kobler til databasen på localhost:3307
```
